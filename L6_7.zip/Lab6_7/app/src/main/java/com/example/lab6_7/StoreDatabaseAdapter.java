package com.example.lab6_7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StoreDatabaseAdapter
{
    private StoreDatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public StoreDatabaseAdapter(Context context){
        dbHelper = new StoreDatabaseHelper(context.getApplicationContext());
    }

    public StoreDatabaseAdapter open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    public void clearDB()
    {
        dbHelper.onUpgrade(database, 1,1);
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {StoreDatabaseHelper.COLUMN_ID, StoreDatabaseHelper.COLUMN_NAME_OF_PRODUCT,
                StoreDatabaseHelper.COLUMN_AMOUNT, StoreDatabaseHelper.COLUMN_PRICE, StoreDatabaseHelper.COLUMN_STATUS};
        return  database.query(StoreDatabaseHelper.TABLE, columns, null, null, null, null, null);
    }

    public List<Product> getProducts(){
        ArrayList<Product> products = new ArrayList<>();
        Cursor cursor = getAllEntries();
        if(cursor.moveToFirst()){
            do{
                int id = cursor.getInt(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_NAME_OF_PRODUCT));
                int amount = cursor.getInt(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_AMOUNT));
                float price = cursor.getFloat(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_PRICE));
                int status = cursor.getInt(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_STATUS));
                products.add(new Product(id, name, amount, price, status));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return products;
    }

    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, StoreDatabaseHelper.TABLE);
    }

    public Product getProduct(long id){
        Product product = null;
        String query = String.format("SELECT * FROM %s WHERE %s=?",StoreDatabaseHelper.TABLE, StoreDatabaseHelper.COLUMN_ID);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(id)});
        if(cursor.moveToFirst()){
            String name = cursor.getString(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_NAME_OF_PRODUCT));
            int amount = cursor.getInt(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_AMOUNT));
            float price = cursor.getFloat(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_PRICE));
            int status = cursor.getInt(cursor.getColumnIndex(StoreDatabaseHelper.COLUMN_STATUS));
            product = new Product(id, name, amount, price, status);
        }
        cursor.close();
        return  product;
    }

    public long insert(Product product){

        ContentValues cv = new ContentValues();
        cv.put(StoreDatabaseHelper.COLUMN_NAME_OF_PRODUCT, product.getName());
        cv.put(StoreDatabaseHelper.COLUMN_AMOUNT, product.getAmount());
        cv.put(StoreDatabaseHelper.COLUMN_PRICE, product.getPrice());
        cv.put(StoreDatabaseHelper.COLUMN_STATUS, product.getStatus());

        return  database.insert(StoreDatabaseHelper.TABLE, null, cv);
    }

    public long delete(long productId){

        String whereClause = "_id = ?";
        String[] whereArgs = new String[]{String.valueOf(productId)};
        return database.delete(StoreDatabaseHelper.TABLE, whereClause, whereArgs);
    }

    public long update(Product product){

        String whereClause = StoreDatabaseHelper.COLUMN_ID + "=" + String.valueOf(product.getId());
        ContentValues cv = new ContentValues();
        cv.put(StoreDatabaseHelper.COLUMN_NAME_OF_PRODUCT, product.getName());
        cv.put(StoreDatabaseHelper.COLUMN_AMOUNT, product.getAmount());
        cv.put(StoreDatabaseHelper.COLUMN_PRICE, product.getPrice());
        cv.put(StoreDatabaseHelper.COLUMN_STATUS, product.getStatus());
        return database.update(StoreDatabaseHelper.TABLE, cv, whereClause, null);
    }
    public long updateWithName(Product product){

        String whereClause = StoreDatabaseHelper.COLUMN_NAME_OF_PRODUCT + "= '" + String.valueOf(product.getName()) + "'";
        ContentValues cv = new ContentValues();
        cv.put(StoreDatabaseHelper.COLUMN_NAME_OF_PRODUCT, product.getName());
        cv.put(StoreDatabaseHelper.COLUMN_AMOUNT, product.getAmount());
        cv.put(StoreDatabaseHelper.COLUMN_PRICE, product.getPrice());
        cv.put(StoreDatabaseHelper.COLUMN_STATUS, product.getStatus());
        return database.update(StoreDatabaseHelper.TABLE, cv, whereClause, null);
    }

    public void zeroizeStatus()
    {
        database.execSQL("UPDATE " + StoreDatabaseHelper.TABLE + " SET " + StoreDatabaseHelper.COLUMN_STATUS + " = 0");
    }
}