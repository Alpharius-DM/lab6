package com.example.lab6_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class BackEndActivity extends AppCompatActivity {

    EditText nameText;
    EditText amountText;
    EditText priceText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back_end);

        nameText = (EditText)findViewById(R.id.nameEditText);
        amountText = (EditText)findViewById(R.id.amountEditText);
        priceText = (EditText)findViewById(R.id.priceEditText);

    }
    public void addProduct(View view)
    {
        StoreDatabaseAdapter storeDatabaseAdapter = DBSingleton.getInstance(this).getStoreDatabaseAdapter();
        storeDatabaseAdapter.open();
        try
        {
            int amount = Integer.parseInt(amountText.getText().toString());
            int price = Integer.parseInt(priceText.getText().toString());
            Product product = new Product(-1, nameText.getText().toString(), amount, price, 4);
            ArrayList<Product> products = (ArrayList<Product>) storeDatabaseAdapter.getProducts();

            ArrayList<Product> productsForTask = new ArrayList<>();

            for (int i = 0; i < products.size(); i++)
            {
                if(products.get(i).getName().equals(product.getName()))
                {
                    Toast.makeText(this, "продукт с таким именем уже есть", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            productsForTask.add(product);
            storeDatabaseAdapter.insert(product);
            new DelayTask(productsForTask).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        }
        catch (Exception ex)
        {
            Toast.makeText(this, "Неверные данные", Toast.LENGTH_SHORT).show();
        }
        finally {
            storeDatabaseAdapter.close();
        }
    }
    public void cancel(View view)
    {
        nameText.setText("");
        amountText.setText("");
        priceText.setText("");
    }
    public void turnOnEditMode(View view)
    {
        Intent intent = new Intent(this, EditModeActivity.class);
        startActivity(intent);
    }
}
