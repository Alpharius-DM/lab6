package com.example.lab6_7;

public class VerificationProductPurchase
{
    public String nameOfProduct;
    public boolean isFirstPurchase = true;

    public VerificationProductPurchase(String name)
    {
        this.nameOfProduct = name;
    }
}
