package com.example.lab6_7;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

class DelayTask extends AsyncTask<Void, Void, Void> {

    private static ArrayList<TaskInfo> info = new ArrayList<>();

    private ArrayList<Product> products;
    private StoreDatabaseAdapter storeDatabaseAdapter;
    public DelayTask(ArrayList<Product> products)
    {
        this.products = products;
        storeDatabaseAdapter = DBSingleton.getInstance(null).getStoreDatabaseAdapter();

    }
    @Override
    protected Void doInBackground(Void... unused)
    {
        Log.d("doInBackground", "------------начало---------- ");
        storeDatabaseAdapter.open();
        //for (int i = 0; i < products.size(); i++)
        //{
         //   info.add(new TaskInfo(products.get(i)));
        //}

        try
        {
            for(int i = 0; i < 4; i++)
            {
                Thread.sleep(1000);
                if(isCancelled())
                {
                    Log.d("doInBackground", "--------Cancel---------");
                    return null;
                }

            }
        }
        catch (InterruptedException e)
        {
            Log.d("doInBackground", e.getMessage());
        }
        return null;
    }
    @Override
    protected void onPostExecute(Void unused)
    {
        FindSameTask(0);
        if(products.size() == 2)
            FindSameTask(1);
    }
    private void FindSameTask(int number)
    {
        /*int indexOfOurTask = -1;
        for(int i = 0; i < info.size(); i++)
        {
            if(info.get(i).product.getName().equals(products.get(number).getName()) &&
                    info.get(i).product.getStatus() == products.get(number).getStatus())
            {
                Log.d("FindSameTask", "----------Соответсвие для " + products.get(number).getName() + " номер " + number + "  количеством " + products.get(number).getAmount());
                if(indexOfOurTask > -1)
                {
                    info.remove(indexOfOurTask);
                    Log.d("FindSameTask", "-------------return " + products.get(number).getName()+ " номер " + number + "  количеством " + products.get(number).getAmount());
                    return;
                }
                indexOfOurTask = i;
            }
        }*/

        if(number == 0)
        {
            if(products.get(0).getStatus() == 1)
            {
                for(int i = 0; i < PageFragment.verificationProducts.size(); i++)
                {
                    if(PageFragment.verificationProducts.get(i).nameOfProduct.equals(products.get(0).getName()))
                    {
                        PageFragment.verificationProducts.remove(i);
                        Log.d("FindSameTask", "удаление " + products.get(0).getName());
                    }
                }
            }
            storeDatabaseAdapter.open();
            Log.d("Задача задержки", "-----------FindSameTask,  установка номер 0 для " + products.get(number).getName());
            int status = products.get(0).getStatus();
            products.get(0).setStatus(0);
            if(status != 4)
                storeDatabaseAdapter.update(products.get(0));
            else
                storeDatabaseAdapter.updateWithName(products.get(0));
        }
        else if(number == 1)
        {
            products.get(1).setStatus(0);
            UserDatabaseAdapter userDatabaseAdapter = DBSingleton.getInstance(null).getUserDatabaseAdapter();
            Log.d("Задача задержки", "---------FindSameTask,  установка номер 1 для " + products.get(number).getName());
            userDatabaseAdapter.open();
            userDatabaseAdapter.update(products.get(1));
        }

        //info.remove(indexOfOurTask);
    }
}
class TaskInfo
{
    public Product product;
    public TaskInfo(Product product)
    {
        this.product = product;
    }
}