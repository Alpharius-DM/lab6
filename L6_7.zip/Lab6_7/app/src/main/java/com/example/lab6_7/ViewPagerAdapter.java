package com.example.lab6_7;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class ViewPagerAdapter extends FragmentPagerAdapter
{
    private ArrayList<Product> products;
    private int goal;
    public ViewPagerAdapter(FragmentManager mgr, ArrayList<Product> products, int goal)
    {
        super(mgr);
        this.products = products;
        this.goal = goal;
    }

    @Override
    public Fragment getItem(int position) {
        return (PageFragment.newInstance(products.get(position), goal));
    }

    @Override
    public int getCount() {
        return products.size();
    }
}
