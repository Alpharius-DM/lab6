package com.example.lab6_7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class ReviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        DBSingleton.getInstance(this).getUserDatabaseAdapter().open();

        ViewPager pager = (ViewPager)findViewById(R.id.review_pager);
        ArrayList<Product> products = (ArrayList<Product>) DBSingleton.getInstance(null).getUserDatabaseAdapter().getProducts();

        ArrayList<Product> zeroStatusProducts = new ArrayList<>();
        for(int i = 0; i < products.size(); i++)
        {
            Log.d("ReviewActivity", "Просмотр продукта " + products.get(i).getName() + " со статусом " +
                    products.get(i).getStatus());
            if(products.get(i).getStatus() == 0)
            {
                zeroStatusProducts.add(products.get(i));
                Log.d("ReviewActivity", "Добавление продукта " + products.get(i).getName());
            }
        }
        pager.setAdapter(new ViewPagerAdapter(getSupportFragmentManager(), zeroStatusProducts ,0));

        if(zeroStatusProducts.size() == 0)
            Toast.makeText(this, "Купленных товаров пока нет", Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onDestroy()
    {
        super.onDestroy();
        DBSingleton.getInstance(null).getUserDatabaseAdapter().close();
    }
}
