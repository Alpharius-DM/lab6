package com.example.lab6_7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import java.util.ArrayList;

public class EditModeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_mode);

        DBSingleton.getInstance(this).getStoreDatabaseAdapter().open();

        ViewPager pager = (ViewPager)findViewById(R.id.editmode_pager);
        ArrayList<Product> products = (ArrayList<Product>) DBSingleton.getInstance(null).getStoreDatabaseAdapter().getProducts();

        pager.setAdapter(new ViewPagerAdapter(getSupportFragmentManager(), products ,2));
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        DBSingleton.getInstance(null).getStoreDatabaseAdapter().close();
    }
}
