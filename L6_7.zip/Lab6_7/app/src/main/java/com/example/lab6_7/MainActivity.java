package com.example.lab6_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView textViewForMoneyOfUser;

    public static final String APP_PREFERENCES = "settings";
    public static final String APP_PREFERENCES_SUM = "sum";
    private SharedPreferences mSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        if (mSettings.contains(APP_PREFERENCES_SUM))
            User.moneyOfUser = mSettings.getInt(APP_PREFERENCES_SUM, 0);

        textViewForMoneyOfUser = (TextView)findViewById(R.id.texf_for_money_of_user);
        textViewForMoneyOfUser.setText("У Вас в наличии " + User.moneyOfUser + " рублей");
    }

    public void showBoughtProducts(View view)
    {
        Intent intent = new Intent(this, ReviewActivity.class);
        startActivity(intent);
    }

    public void buyNewProducts(View view)
    {
        Intent intent = new Intent(this, PurchaseActivity.class);
        startActivity(intent);
    }

    public void editMode(View view)
    {
        Intent intent = new Intent(this, BackEndActivity.class);
        startActivity(intent);
    }

    public void addOneHundred(View view)
    {
        User.moneyOfUser += 100;
        textViewForMoneyOfUser.setText("У Вас в наличии " + User.moneyOfUser + " рублей");
    }
    public void addOneThousand(View view)
    {
        User.moneyOfUser += 1000;
        textViewForMoneyOfUser.setText("У Вас в наличии " + User.moneyOfUser + " рублей");
    }
    public void addTenThousand(View view)
    {
        User.moneyOfUser += 10000;
        textViewForMoneyOfUser.setText("У Вас в наличии " + User.moneyOfUser + " рублей");
    }

    public void clearDB(View view)
    {
        User.moneyOfUser = 10000;
        textViewForMoneyOfUser.setText("У Вас в наличии " + User.moneyOfUser + " рублей");
        UserDatabaseAdapter userDatabaseAdapter = DBSingleton.getInstance(this).getUserDatabaseAdapter();
        StoreDatabaseAdapter storeDatabaseAdapter = DBSingleton.getInstance(this).getStoreDatabaseAdapter();

        userDatabaseAdapter.open();
        userDatabaseAdapter.clearDB();
        userDatabaseAdapter.close();

        storeDatabaseAdapter.open();
        storeDatabaseAdapter.clearDB();
        storeDatabaseAdapter.close();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        textViewForMoneyOfUser.setText("У Вас в наличии " + User.moneyOfUser + " рублей");

    }

    @Override
    protected void onPause ()
    {
        super.onPause();
        SharedPreferences.Editor editor = mSettings.edit();
        editor.putInt(APP_PREFERENCES_SUM, User.moneyOfUser);
        editor.apply();
    }
    @Override
    protected void onDestroy()
    {

        super.onDestroy();
        StoreDatabaseAdapter storeDatabaseAdapter = DBSingleton.getInstance(null).getStoreDatabaseAdapter();
        storeDatabaseAdapter.open();
        ArrayList<Product> products = (ArrayList<Product>) storeDatabaseAdapter.getProducts();
        for(int i = 0; i < products.size(); i++)
        {
            if(products.get(i).getStatus() != 0)
            {
                products.get(i).setStatus(0);
                storeDatabaseAdapter.update(products.get(i));
            }
        }
        storeDatabaseAdapter.close();
    }
}
